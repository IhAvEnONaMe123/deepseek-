#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created by 蔡语轩, 
11/4/2025
"""

import sys
import json
import time
import requests
import pyttsx3
import pyaudio
from vosk import Model as VoskModel, KaldiRecognizer

from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QVBoxLayout, QHBoxLayout, QTextEdit,
    QLabel, QLineEdit, QComboBox
)
from PyQt6.QtGui import QMovie, QPixmap, QPainter
from PyQt6.QtCore import QSize, QTimer
from datetime import datetime


# 全局配置
MODEL_PATH = "models/vosk-model-small-cn-0.22"  # Vosk 离线模型目录
SAMPLE_RATE = 16000
CHANNELS = 1
CHUNK = 4096
SILENCE_TIMEOUT = 1.5  # 静音阈值（秒）


class ChatWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.bg = QPixmap("images/background1.JPG")
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  
        self.setWindowTitle("AI 语音助手")
        self.resize(600,800)
        # 默认使用的模型和GIF
        self.current_model = "deepseek-r1:1.5b"
        self.current_gif = "images/character.GIF"
        # 初始化界面、TTS和Vosk模型
        self.init_ui()
        self.tts_engine = pyttsx3.init()
        self.vosk_model = VoskModel(MODEL_PATH)

    def init_ui(self):
        # 主水平布局：左侧聊天区，右侧控制区
        # 左侧布局
        main_layout = QHBoxLayout()
        left_layout = QVBoxLayout()
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        left_layout.addWidget(self.chat_display)
        self.input_line = QLineEdit()
        left_layout.addWidget(self.input_line)
        btn_layout = QHBoxLayout()
        self.send_button = QPushButton("发送")
        self.voice_button = QPushButton("语音输入")
        self.clear_button = QPushButton("清空")
        btn_layout.addWidget(self.send_button)
        btn_layout.addWidget(self.voice_button)
        btn_layout.addWidget(self.clear_button)
        left_layout.addLayout(btn_layout)

        # 右侧布局
        right_layout = QVBoxLayout()
        # 右上：当前实现显示标签
        self.impl_label = QLabel()
        right_layout.addWidget(self.impl_label)
        # 右中：模型和GIF切换控件（水平布局）
        control_layout = QVBoxLayout()
        self.model_combo = QComboBox()
        self.model_combo.addItem("deepseek-r1:1.5b")
        self.model_combo.addItem("deepseek-r1:14b")
        self.model_combo.currentIndexChanged.connect(self.on_model_change)
        control_layout.addWidget(QLabel("模型："))
        control_layout.addWidget(self.model_combo)
        self.gif_combo = QComboBox()
        # GIF动画
        self.gif_combo.addItem("images/character.GIF")
        self.gif_combo.addItem("images/character1.GIF")
        self.gif_combo.addItem("images/character2.GIF")
        self.gif_combo.currentIndexChanged.connect(self.on_gif_change)
        control_layout.addWidget(QLabel("形象："))
        control_layout.addWidget(self.gif_combo)
        right_layout.addLayout(control_layout)
        # 右下：显示GIF动画的标签
        self.gif_label = QLabel()
        self.movie = QMovie(self.current_gif)
        self.movie.setScaledSize(QSize(195, 200))  # 调整GIF显示大小
        self.gif_label.setMovie(self.movie)
        self.movie.start()
        right_layout.addWidget(self.gif_label)
        # 将左右布局添加到主布局中，左侧占比2，右侧占比1
        main_layout.addLayout(left_layout, 2)
        main_layout.addLayout(right_layout, 1)
        self.setLayout(main_layout)

        # 信号连接
        self.send_button.clicked.connect(self.handle_send)
        self.voice_button.clicked.connect(self.handle_voice)
        self.clear_button.clicked.connect(self.chat_display.clear)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setOpacity(0.1)  # 设置透明度为50%
        painter.drawPixmap(self.rect(), self.bg)
        # 如果后续绘制其他内容，希望保持不透明，可以恢复透明度
        painter.setOpacity(1.0)
        super().paintEvent(event)

    def on_model_change(self, index):
        self.current_model = self.model_combo.currentText()
        self.impl_label.setText(f"默认实现：{self.current_model}")

    def on_gif_change(self, index):
        self.current_gif = self.gif_combo.currentText()
        self.movie.stop()
        self.movie = QMovie(self.current_gif)
        self.movie.setScaledSize(QSize(195, 200))
        self.gif_label.setMovie(self.movie)
        self.movie.start()

    def handle_send(self):
        text = self.input_line.text().strip()
        if not text:
            return
        self.chat_display.append("YOU: " + text)
        self.input_line.clear()
        response_text = self.send_to_deepseek(text, self.current_model)
        self.chat_display.append("AI: " + response_text)
        self.speak(response_text)

    def handle_voice(self):
        self.chat_display.append("【开始录音，请说话…】")
        recognized_text = self.record_voice()
        if recognized_text:
            self.chat_display.append("YOU: " + recognized_text)
            response_text = self.send_to_deepseek(recognized_text, self.current_model)
            self.chat_display.append("AI：" + response_text)
            self.speak(response_text)
        else:
            self.chat_display.append("未识别到有效语音。")

    def record_voice(self):
        rec = KaldiRecognizer(self.vosk_model, SAMPLE_RATE)
        p = pyaudio.PyAudio()
        stream = p.open(format=pyaudio.paInt16,
                        channels=CHANNELS,
                        rate=SAMPLE_RATE,
                        input=True,
                        frames_per_buffer=CHUNK)
        stream.start_stream()
        last_spoke_time = time.time()
        recognized_text = ""
        while True:
            try:
                data = stream.read(CHUNK, exception_on_overflow=False)
            except Exception as e:
                print("录音异常：", e)
                break
            if rec.AcceptWaveform(data):
                result_json = rec.Result()
                result = json.loads(result_json)
                text = result.get("text", "")
                if text.strip():
                    recognized_text += text + " "
                    last_spoke_time = time.time()
            else:
                partial_json = rec.PartialResult()
                partial = json.loads(partial_json).get("partial", "")
                if partial.strip():
                    last_spoke_time = time.time()
            if time.time() - last_spoke_time > SILENCE_TIMEOUT:
                break
        stream.stop_stream()
        stream.close()
        p.terminate()
        final_json = rec.FinalResult()
        final_result = json.loads(final_json).get("text", "")
        if final_result.strip():
            recognized_text += final_result + " "
        return recognized_text.strip()

    def send_to_deepseek(self, prompt, model):
        url = "http://127.0.0.1:11434/api/generate"
        headers = {"Content-Type": "application/json"}
        data = {"model": model, "prompt": prompt}
        try:
            response = requests.post(url=url, headers=headers, json=data, stream=True)
        except Exception as e:
            return "请求 AI 服务失败: " + str(e)
        full_text = ""
        for line in response.iter_lines(decode_unicode=True):
            if line:
                try:
                    json_data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if "response" in json_data:
                    chunk = json_data["response"]
                    full_text += chunk
                if "done" in json_data and json_data["done"]:
                    break
        try:
            words1 = full_text.split("<think>")
            words = words1[1].split("</think>")
            return words[1].strip()
        except Exception as e:
            return full_text.strip()

    def speak(self, text):
        self.tts_engine.say(text)
        self.tts_engine.runAndWait()

    def update_time(self):
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.impl_label.setText(f"当前时间: {current_time}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ChatWindow()
    window.show()
    sys.exit(app.exec())